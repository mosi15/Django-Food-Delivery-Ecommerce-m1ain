asd = [
    {
        "id": "01",
        "title": "Chicken Burger",
        "price": 24.0,
        "category": "Burger",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque. ",
        "is_visible": True
    },

    {
        "id": "02",
        "title": "Vegetarian Pizza",
        "price": 115.0,
        "category": "Pizza",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    },

    {
        "id": "03",
        "title": "Double Cheese Margherita",
        "price": 110.0,
        "category": "Pizza",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    },

    {
        "id": "04",
        "title": "Maxican Green Wave",
        "price": 110.0,
        "category": "Pizza",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    },

    {
        "id": "05",
        "title": "Cheese Burger",
        "price": 24.0,
        "category": "Burger",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    },
    {
        "id": "06",
        "title": "Royal Cheese Burger",
        "price": 24.0,
        "category": "Burger",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    },

    {
        "id": "07",
        "title": "Seafood Pizza",
        "price": 115.0,
        "category": "Pizza",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    },

    {
        "id": "08",
        "title": "Thin Cheese Pizza",
        "price": 110.0,
        "category": "Pizza",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    },

    {
        "id": "09",
        "title": "Pizza With Mushroom",
        "price": 110.0,
        "category": "Pizza",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    },

    {
        "id": "10",
        "title": "Classic Hamburger",
        "price": 24.0,
        "category": "Burger",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    },

    {
        "id": "11",
        "title": "Crunchy Bread ",
        "price": 35.0,
        "category": "Bread",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    },

    {
        "id": "12",
        "title": "Delicious Bread ",
        "price": 35.0,
        "category": "Bread",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    },

    {
        "id": "13",
        "title": "Loaf Bread ",
        "price": 35.0,
        "category": "Bread",

        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Soluta ad et est, fugiat repudiandae neque illo delectus commodi magnam explicabo autem voluptates eaque velit vero facere mollitia. Placeat rem, molestiae error obcaecati enim doloribus impedit aliquam, maiores qui minus neque.",
        "is_visible": True
    }
]
